export const navTabs = [
  { id: 'dashboard',    label: '📊  Safety Dashboard' },
  { id: 'navigation', label: '🗺️  Navigation' },
  { id: 'alerts',       label: '⚠️  Emergency Alerts' },
  { id: 'notifications',label: '🔔  Notifications' },
  { id: 'admin',         label: '🛠️  Admin Dashboard' },
  { id: 'features',      label: '✨  Features' },
  { id: 'help',           label: '🆘  Help & Support' },
];

// Campus & block data now comes live from OpenStreetMap (see src/utils/overpass.js)
// based on the user's real GPS location — no hardcoded campus list.

// Map a block label to an emoji icon
export function getBlockIcon(label) {
  const l = label.toLowerCase();
  if (l.includes('gate'))                            return '🚪';
  if (l.includes('admin'))                           return '🏢';
  if (l.includes('principal'))                       return '👔';
  if (l.includes('library'))                         return '📚';
  if (l.includes('cse') || l.includes('computer'))   return '💻';
  if (l.includes('ece') || l.includes('electrical'))  return '⚡';
  if (l.includes('mechanical'))                      return '⚙️';
  if (l.includes('civil'))                           return '🏗️';
  if (l.includes('hostel'))                          return '🏠';
  if (l.includes('canteen') || l.includes('food'))   return '🍽️';
  if (l.includes('sport') || l.includes('ground'))   return '⚽';
  if (l.includes('medical') || l.includes('health')) return '🏥';
  if (l.includes('parking'))                         return '🅿️';
  if (l.includes('seminar') || l.includes('audi'))   return '🎭';
  if (l.includes('lab') || l.includes('research'))   return '🔬';
  if (l.includes('faculty') || l.includes('staff'))  return '👨‍🏫';
  if (l.includes('visitor'))                         return '📋';
  if (l.includes('engineering'))                     return '🔧';
  if (l.includes('mba') || l.includes('business'))   return '💼';
  return '🏛️';
}
