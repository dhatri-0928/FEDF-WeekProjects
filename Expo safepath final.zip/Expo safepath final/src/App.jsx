import { useState, useEffect, useRef, useCallback } from 'react';
import appStyles from './appStyles';
import { buildNavResult, buildSafePathResult, findMainGate } from './utils/directions';
import { watchLocation, clearLocationWatch } from './utils/geo';
import { searchNearbyCampuses, fetchCampusBuildings } from './utils/overpassApi';
import { fetchWalkingRoute } from './utils/routingApi';
import { getCustomBlocks, mergeBlocks } from './utils/blocksStore';
import { isBlockAlerted, getActiveAlertsForCampus, unreadNotificationCount } from './utils/alertsStore';
import { isAdmin as checkIsAdmin, adminLogout } from './utils/adminAuth';
import { getSession, startSession, endSession, onSessionChange } from './utils/sessionStore';
import HomePage from './components/pages/HomePage';
import AuthPage from './components/pages/AuthPage';
import DashboardPage from './components/pages/DashboardPage';

export default function App() {
  /* ── view state ─────────────────────────── */
  const [view, setView]             = useState('home');
  const [isLoginMode, setIsLoginMode] = useState(true);

  /* ── user session (persisted, synced across tabs) ──────── */
  const [session, setSession] = useState(getSession());

  // If another tab logs in/out, mirror it here instantly — and if
  // a logged-in session already exists on first load (e.g. refresh,
  // or opened in a new tab after signing in elsewhere), jump
  // straight into the dashboard instead of the public landing page.
  useEffect(() => {
    if (session && view === 'home') setView('main');
    const unsubscribe = onSessionChange(next => {
      setSession(next);
      setView(next ? 'main' : 'home');
    });
    return unsubscribe;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /* ── admin state ────────────────────────── */
  const [adminMode, setAdminMode] = useState(checkIsAdmin());

  /* ── live GPS location ─────────────────── */
  const [liveLocation, setLiveLocation]   = useState(null);
  const [locating, setLocating]           = useState(true);
  const [locationError, setLocationError] = useState(null);
  const watchIdRef = useRef(null);

  useEffect(() => {
    watchIdRef.current = watchLocation(
      loc => {
        setLiveLocation(loc);
        setLocating(false);
        setLocationError(null);
      },
      err => {
        setLocating(false);
        setLocationError(
          err.code === 1 /* PERMISSION_DENIED */
            ? 'Location access was denied. Please allow location access to find nearby campuses.'
            : (err.message || 'Could not get your live location.')
        );
      }
    );
    return () => clearLocationWatch(watchIdRef.current);
  }, []);

  /* ── nearby campuses (live, from OpenStreetMap) + search box ── */
  const [nearbyCampuses, setNearbyCampuses] = useState([]);
  const [searchLoading, setSearchLoading]   = useState(false);
  const [hasSearched, setHasSearched]       = useState(false);
  const [query, setQuery]                   = useState('');
  const [selectedCampus, setSelectedCampus] = useState(null);

  useEffect(() => {
    if (!liveLocation) return;
    let cancelled = false;
    setSearchLoading(true);
    searchNearbyCampuses(liveLocation.lat, liveLocation.lng)
      .then(list => {
        if (cancelled) return;
        setNearbyCampuses(list);
        setHasSearched(true);
      })
      .catch(() => {
        if (cancelled) return;
        setNearbyCampuses([]);
        setHasSearched(true);
      })
      .finally(() => { if (!cancelled) setSearchLoading(false); });
    return () => { cancelled = true; };
    // re-search only when the live fix moves to a new ~1km grid cell
  }, [liveLocation?.lat?.toFixed(2), liveLocation?.lng?.toFixed(2)]);

  const suggestions = nearbyCampuses.filter(c =>
    c.label.toLowerCase().includes(query.trim().toLowerCase())
  );

  function handleCampusSelect(campus) {
    setSelectedCampus(campus);
    setQuery(campus.label);
  }

  function handleCampusClear() {
    setSelectedCampus(null);
    setQuery('');
  }

  /* ── blocks ("locations") inside the selected campus ──────
   * Merges live OSM-fetched buildings with admin-added custom
   * blocks (e.g. "ECE Block", "Hostel") saved in localStorage,
   * since OSM rarely has these tagged for Indian campuses.    */
  const [osmBlocks, setOsmBlocks]             = useState([]);
  const [campusLocations, setCampusLocations] = useState([]);
  const [blocksLoading, setBlocksLoading]      = useState(false);

  const refreshCampusBlocks = useCallback(() => {
    if (!selectedCampus) { setCampusLocations([]); return; }
    const custom = getCustomBlocks(selectedCampus.id);
    setCampusLocations(mergeBlocks(osmBlocks, custom));
  }, [selectedCampus, osmBlocks]);

  useEffect(() => {
    if (!selectedCampus) {
      setOsmBlocks([]);
      setCampusLocations([]);
      return;
    }
    let cancelled = false;
    setBlocksLoading(true);
    fetchCampusBuildings(selectedCampus)
      .then(blocks => {
        if (cancelled) return;
        setOsmBlocks(blocks);
        const custom = getCustomBlocks(selectedCampus.id);
        setCampusLocations(mergeBlocks(blocks, custom));
      })
      .catch(() => {
        if (cancelled) return;
        setOsmBlocks([]);
        const custom = getCustomBlocks(selectedCampus.id);
        setCampusLocations(mergeBlocks([], custom));
      })
      .finally(() => { if (!cancelled) setBlocksLoading(false); });
    return () => { cancelled = true; };
  }, [selectedCampus]);

  /* ── emergency alerts for the selected campus ─────────────── */
  const [alertedBlocks, setAlertedBlocks] = useState([]);
  const [activeAlertCount, setActiveAlertCount] = useState(0);
  const [unreadCount, setUnreadCount] = useState(0);

  const refreshAlertsState = useCallback(() => {
    if (selectedCampus) {
      const active = getActiveAlertsForCampus(selectedCampus.id);
      setAlertedBlocks(active.map(a => a.blockLabel));
      setActiveAlertCount(active.length);
    } else {
      setAlertedBlocks([]);
      setActiveAlertCount(0);
    }
    setUnreadCount(unreadNotificationCount());
  }, [selectedCampus]);

  useEffect(() => {
    refreshAlertsState();
    const interval = setInterval(refreshAlertsState, 2000);
    return () => clearInterval(interval);
  }, [refreshAlertsState]);

  /* ── route / navigation state ────────────────────────────── */
  const [destinationNode, setDestinationNode] = useState('');
  const [navResult, setNavResult]             = useState(null);
  const [tracking, setTracking]               = useState(false);

  /* reset destination + result whenever the campus changes */
  useEffect(() => {
    setDestinationNode('');
    setNavResult(null);
    setTracking(false);
  }, [selectedCampus]);

  /* ── core directions logic, with safe-path rerouting ──────── */
  const computeDirections = useCallback(async (destLabel) => {
    const dest = campusLocations.find(l => l.label === destLabel);
    if (!dest || !liveLocation || !selectedCampus) return;
    const origin = { ...liveLocation, label: 'Your Live Location' };

    if (isBlockAlerted(selectedCampus.id, destLabel)) {
      // Danger! Redirect to the campus main gate instead of the requested block.
      const mainGate = findMainGate(selectedCampus, campusLocations);
      const realRoute = await fetchWalkingRoute(liveLocation, mainGate);
      setNavResult(buildSafePathResult(origin, destLabel, mainGate, realRoute));
      setTracking(true);
      return;
    }

    const realRoute = await fetchWalkingRoute(liveLocation, dest);
    setNavResult(buildNavResult(origin, dest, realRoute));
    setTracking(true);
  }, [campusLocations, liveLocation, selectedCampus]);

  const handleGetDirections = () => computeDirections(destinationNode);

  const handleToggleTracking = () => setTracking(t => !t);

  /* live re-route as the user walks, while tracking is on —
   * also continuously re-checks for newly-raised alerts so an
   * in-progress walk reroutes the instant danger is declared.  */
  useEffect(() => {
    if (!tracking || !destinationNode || !liveLocation || !selectedCampus) return;
    let cancelled = false;

    const dest = campusLocations.find(l => l.label === destinationNode);
    if (!dest) return;

    const origin = { ...liveLocation, label: 'Your Live Location' };

    if (isBlockAlerted(selectedCampus.id, destinationNode)) {
      const mainGate = findMainGate(selectedCampus, campusLocations);
      fetchWalkingRoute(liveLocation, mainGate).then(realRoute => {
        if (!cancelled) setNavResult(buildSafePathResult(origin, destinationNode, mainGate, realRoute));
      });
    } else {
      fetchWalkingRoute(liveLocation, dest).then(realRoute => {
        if (!cancelled) setNavResult(buildNavResult(origin, dest, realRoute));
      });
    }
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [liveLocation?.lat, liveLocation?.lng, tracking, alertedBlocks.length]);

  /* clicking a block card sets it as destination + auto-navigates */
  const handleBlockClick = (label) => {
    setDestinationNode(label);
    computeDirections(label);
  };

  const openLoginView  = () => { setView('auth'); setIsLoginMode(true); };
  const openPublicHome = () => setView('home');
  const handleAuthSubmit = ({ name, email }) => {
    const newSession = startSession({ name, email });
    setSession(newSession);
    setView('main');
  };
  const handleLogout = () => {
    endSession();
    setSession(null);
    setView('home');
  };

  const handleAdminLoginSuccess = () => setAdminMode(true);
  const handleAdminLogout = () => { adminLogout(); setAdminMode(false); };

  return (
    <div className="app-shell">
      <style>{appStyles}</style>

      <HomePage view={view} openLoginView={openLoginView} />

      <AuthPage
        view={view}
        openPublicHome={openPublicHome}
        isLoginMode={isLoginMode}
        setIsLoginMode={setIsLoginMode}
        handleAuthSubmit={handleAuthSubmit}
      />

      <DashboardPage
        view={view}
        openPublicHome={openPublicHome}
        session={session}
        onLogout={handleLogout}
        query={query}
        onQueryChange={setQuery}
        suggestions={suggestions}
        selectedCampus={selectedCampus}
        locating={locating}
        locationError={locationError}
        searchLoading={searchLoading}
        hasSearched={hasSearched}
        nearbyCount={nearbyCampuses.length}
        campusLocations={campusLocations}
        blocksLoading={blocksLoading}
        liveLocation={liveLocation}
        destinationNode={destinationNode}
        navResult={navResult}
        tracking={tracking}
        alertedBlocks={alertedBlocks}
        activeAlertCount={activeAlertCount}
        unreadCount={unreadCount}
        isAdmin={adminMode}
        onCampusSelect={handleCampusSelect}
        onCampusClear={handleCampusClear}
        onDestinationChange={setDestinationNode}
        onBlockClick={handleBlockClick}
        onGetDirections={handleGetDirections}
        onToggleTracking={handleToggleTracking}
        onBlocksChanged={refreshCampusBlocks}
        onNotificationsChanged={refreshAlertsState}
        onAdminLoginSuccess={handleAdminLoginSuccess}
        onAdminLogout={handleAdminLogout}
      />
    </div>
  );
}
