import React, { useState, useRef, useEffect } from 'react';

export default function CampusAutocomplete({
  query,
  onQueryChange,
  suggestions,
  onSelect,
  selectedCampus,
  onClear,
  locating,
  locationError,
  searchLoading,
  hasSearched,
  nearbyCount,
}) {
  const [open, setOpen] = useState(false);
  const boxRef = useRef(null);

  useEffect(() => {
    function handleClickOutside(e) {
      if (boxRef.current && !boxRef.current.contains(e.target)) setOpen(false);
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const showDropdown = open && query.trim().length > 0 && !selectedCampus;
  const fmtKm = m => (m < 1000 ? `${Math.round(m)} m away` : `${(m / 1000).toFixed(1)} km away`);

  return (
    <div className="campus-selector-section" ref={boxRef}>
      <p className="nl-section-label">📍 Enter Campus Name</p>

      {locating && (
        <p className="nl-hint">Finding your live location…</p>
      )}

      {locationError && (
        <p className="nl-hint nl-hint-error">
          ⚠️ {locationError} — allow location access to search nearby colleges.
        </p>
      )}

      {selectedCampus ? (
        <div className="campus-selected-pill">
          <span>🎓 {selectedCampus.label}</span>
          <button className="campus-clear-btn" onClick={onClear} title="Change campus">✕</button>
        </div>
      ) : (
        <div style={{ position: 'relative' }}>
          <input
            className="campus-select-control"
            type="text"
            placeholder={locating ? 'Locating you…' : 'Start typing a college / campus name…'}
            value={query}
            disabled={locating || !!locationError}
            onChange={e => { onQueryChange(e.target.value); setOpen(true); }}
            onFocus={() => setOpen(true)}
          />

          {showDropdown && (
            <div className="campus-autocomplete-dropdown">
              {searchLoading && (
                <div className="campus-autocomplete-item campus-autocomplete-empty">Searching nearby colleges…</div>
              )}

              {!searchLoading && suggestions.length === 0 && hasSearched && (
                <div className="campus-autocomplete-item campus-autocomplete-empty">
                  No colleges found matching "{query}" near you.
                </div>
              )}

              {!searchLoading && suggestions.map(c => (
                <div
                  key={c.id}
                  className="campus-autocomplete-item"
                  onClick={() => { onSelect(c); setOpen(false); }}
                >
                  <span className="campus-autocomplete-name">🎓 {c.label}</span>
                  <span className="campus-autocomplete-dist">{fmtKm(c.distance)}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {!selectedCampus && !locating && !locationError && hasSearched && nearbyCount === 0 && (
        <p className="nl-hint nl-hint-error">
          There are no colleges near your location.
        </p>
      )}
    </div>
  );
}
