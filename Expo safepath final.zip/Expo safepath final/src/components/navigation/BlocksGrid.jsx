import React from 'react';
import { getBlockIcon } from '../../data/constants';

export default function BlocksGrid({ selectedCampus, locations, loading, destinationNode, onBlockClick, alertedBlocks = [] }) {
  if (!selectedCampus) return null; // nothing entered yet → show no blocks at all

  const isAlerted = (label) => alertedBlocks.some(b => b.toLowerCase() === label.toLowerCase());

  return (
    <div className="blocks-section">
      <div className="blocks-section-header">
        <p className="nl-section-label" style={{ margin: 0 }}>🏛️ {selectedCampus.label} — Blocks</p>
        {!loading && <span className="blocks-count-pill">{locations.length} blocks</span>}
      </div>

      {loading && (
        <p className="nl-hint">Loading live block locations for this campus…</p>
      )}

      {!loading && locations.length === 0 && (
        <p className="nl-hint nl-hint-error">
          No blocks found for {selectedCampus.label} yet. Ask an admin to add blocks in the
          Admin Dashboard.
        </p>
      )}

      {!loading && locations.length > 0 && (
        <>
          <div className="blocks-grid">
            {locations.map(loc => {
              const isDest    = loc.label === destinationNode;
              const isDanger  = isAlerted(loc.label);
              let cls = 'block-card';
              if (isDest)   cls += ' bc-dest';
              if (isDanger) cls += ' bc-danger';

              return (
                <div
                  key={loc.label}
                  className={cls}
                  onClick={() => onBlockClick(loc.label)}
                  title={isDanger ? '⚠️ Alert active — you will be routed to a safe path' : isDest ? 'Current destination' : 'Navigate here'}
                >
                  <span className="block-icon">{isDanger ? '🚨' : getBlockIcon(loc.label)}</span>
                  <span className="block-label">{loc.label}{loc.custom ? '' : ''}</span>
                </div>
              );
            })}
          </div>

          <p style={{ fontSize: '0.75rem', color: '#6b9c84', margin: '10px 0 0', lineHeight: 1.4 }}>
            Tap a block to start live navigation from your current location
            {alertedBlocks.length > 0 && ' · 🚨 blocks marked unsafe will redirect you to the main gate'}
          </p>
        </>
      )}
    </div>
  );
}
