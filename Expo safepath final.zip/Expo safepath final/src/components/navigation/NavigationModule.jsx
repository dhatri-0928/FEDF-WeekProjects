import React, { useState } from 'react';
import CampusAutocomplete from './CampusAutocomplete';
import BlocksGrid      from './BlocksGrid';
import RoutePanel      from './RoutePanel';
import DirectionsPanel from './DirectionsPanel';
import MapView         from './MapView';
import LiveMapSVG       from './LiveMapSVG';

export default function NavigationModule({
  query,
  onQueryChange,
  suggestions,
  selectedCampus,
  locating,
  locationError,
  searchLoading,
  hasSearched,
  nearbyCount,
  campusLocations,
  blocksLoading,
  liveLocation,
  destinationNode,
  navResult,
  tracking,
  alertedBlocks,
  onCampusSelect,
  onCampusClear,
  onDestinationChange,
  onBlockClick,
  onGetDirections,
  onToggleTracking,
}) {
  const [mapMode, setMapMode] = useState('tiles'); // 'tiles' | 'svg'

  return (
    <div className="nav-module-wrapper">

      {/* ══ LEFT PANEL ════════════════════════════════════════ */}
      <div className="nav-left-panel">
        <div className="nav-left-scroll">

          {/* 1 – Campus search (autocomplete, restricted to nearby colleges) */}
          <CampusAutocomplete
            query={query}
            onQueryChange={onQueryChange}
            suggestions={suggestions}
            onSelect={onCampusSelect}
            selectedCampus={selectedCampus}
            onClear={onCampusClear}
            locating={locating}
            locationError={locationError}
            searchLoading={searchLoading}
            hasSearched={hasSearched}
            nearbyCount={nearbyCount}
          />

          {/* 2 – All blocks in the selected campus (nothing until a campus is chosen) */}
          <BlocksGrid
            selectedCampus={selectedCampus}
            locations={campusLocations}
            loading={blocksLoading}
            destinationNode={destinationNode}
            onBlockClick={onBlockClick}
            alertedBlocks={alertedBlocks}
          />

          {/* 3 – Route planner (live location → selected block) */}
          <RoutePanel
            selectedCampus={selectedCampus}
            locations={campusLocations}
            destinationNode={destinationNode}
            liveLocation={liveLocation}
            onDestinationChange={onDestinationChange}
            onGetDirections={onGetDirections}
            alertedBlocks={alertedBlocks}
          />

          {/* 4 – Info tiles + turn-by-turn directions */}
          <DirectionsPanel
            selectedCampus={selectedCampus}
            navResult={navResult}
          />

        </div>
      </div>

      {/* ══ RIGHT PANEL – LIVE MAP ════════════════════════════ */}
      <div className="nav-right-panel" style={{ position: 'relative' }}>
        <div className="map-mode-toggle">
          <button className={mapMode === 'tiles' ? 'active' : ''} onClick={() => setMapMode('tiles')}>🌍 Map</button>
          <button className={mapMode === 'svg' ? 'active' : ''} onClick={() => setMapMode('svg')}>🛰️ Live SVG</button>
        </div>

        {mapMode === 'tiles' ? (
          <MapView
            selectedCampus={selectedCampus}
            campusLocations={campusLocations}
            liveLocation={liveLocation}
            destinationNode={destinationNode}
            navResult={navResult}
            tracking={tracking}
            onToggleTracking={onToggleTracking}
            alertedBlocks={alertedBlocks}
          />
        ) : (
          <LiveMapSVG
            selectedCampus={selectedCampus}
            campusLocations={campusLocations}
            liveLocation={liveLocation}
            destinationNode={destinationNode}
            navResult={navResult}
            alertedBlocks={alertedBlocks}
          />
        )}
      </div>

    </div>
  );
}
