import React, { useMemo } from 'react';
import { getBlockIcon } from '../../data/constants';

const VB_W = 640;
const VB_H = 480;
const PAD  = 60;

/**
 * Projects every lat/lng point we need to draw into a shared local
 * coordinate space (simple equirectangular fit — campuses are small
 * enough that this reads as accurate, and it avoids pulling in a
 * mapping library for what's meant to be a lightweight SVG view).
 */
function useProjector(points) {
  return useMemo(() => {
    const valid = points.filter(p => p && Number.isFinite(p.lat) && Number.isFinite(p.lng));
    if (valid.length === 0) return null;

    let minLat = Infinity, maxLat = -Infinity, minLng = Infinity, maxLng = -Infinity;
    valid.forEach(p => {
      minLat = Math.min(minLat, p.lat); maxLat = Math.max(maxLat, p.lat);
      minLng = Math.min(minLng, p.lng); maxLng = Math.max(maxLng, p.lng);
    });

    // guard against a zero-size bounding box (single point, etc.)
    const latSpan = Math.max(maxLat - minLat, 0.0008);
    const lngSpan = Math.max(maxLng - minLng, 0.0008);

    const innerW = VB_W - PAD * 2;
    const innerH = VB_H - PAD * 2;

    return (lat, lng) => {
      const x = PAD + ((lng - minLng) / lngSpan) * innerW;
      const y = PAD + (1 - (lat - minLat) / latSpan) * innerH; // flip Y (north = up)
      return [x, y];
    };
  }, [points]);
}

export default function LiveMapSVG({
  selectedCampus,
  campusLocations = [],
  liveLocation,
  destinationNode,
  navResult,
  alertedBlocks = [],
}) {
  const dest = campusLocations.find(l => l.label === destinationNode);
  const isAlerted = (label) => alertedBlocks.some(b => b.toLowerCase() === label.toLowerCase());

  const allPoints = useMemo(() => {
    const pts = [...campusLocations];
    if (liveLocation) pts.push(liveLocation);
    if (navResult?.geometry?.length) {
      navResult.geometry.forEach(([lat, lng]) => pts.push({ lat, lng }));
    }
    return pts;
  }, [campusLocations, liveLocation, navResult]);

  const project = useProjector(allPoints);

  const hasDanger = alertedBlocks.length > 0;

  if (!selectedCampus) {
    return (
      <div className="svg-map-wrap">
        <div className="svg-map-empty">
          <div className="svg-map-empty-icon">🗺️</div>
          <p>Select a campus in the Navigation tab to see the live map.</p>
        </div>
      </div>
    );
  }

  if (!project) {
    return (
      <div className="svg-map-wrap">
        <div className="svg-map-empty">
          <div className="svg-map-empty-icon">📡</div>
          <p>Waiting for live location and campus block data…</p>
        </div>
      </div>
    );
  }

  const routePoints = navResult?.geometry?.length
    ? navResult.geometry.map(([lat, lng]) => project(lat, lng))
    : null;
  const routePath = routePoints ? routePoints.map(([x, y]) => `${x.toFixed(1)},${y.toFixed(1)}`).join(' ') : null;

  const [liveX, liveY] = liveLocation ? project(liveLocation.lat, liveLocation.lng) : [null, null];
  const [destX, destY] = dest ? project(dest.lat, dest.lng) : [null, null];

  return (
    <div className="svg-map-wrap">

      {/* status strip */}
      <div className={`svg-map-status ${hasDanger ? 'svg-map-status-danger' : 'svg-map-status-safe'}`}>
        {hasDanger
          ? <>🚨 Danger detected — {alertedBlocks.length} zone{alertedBlocks.length > 1 ? 's' : ''} unsafe. Rerouting away from hazard.</>
          : <>🟢 No danger detected — all routes at {selectedCampus.label} are currently safe.</>}
      </div>

      <svg viewBox={`0 0 ${VB_W} ${VB_H}`} preserveAspectRatio="xMidYMid meet" style={{ width: '100%', height: '100%' }}>
        <defs>
          <radialGradient id="liveDotGlow" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#ff3b30" stopOpacity="0.55" />
            <stop offset="100%" stopColor="#ff3b30" stopOpacity="0" />
          </radialGradient>
          <radialGradient id="hazardGlow" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#ef4444" stopOpacity="0.45" />
            <stop offset="100%" stopColor="#ef4444" stopOpacity="0" />
          </radialGradient>
        </defs>

        {/* soft ground grid for spatial context */}
        {Array.from({ length: 8 }).map((_, i) => (
          <line key={`v${i}`} x1={(i + 1) * (VB_W / 9)} y1={0} x2={(i + 1) * (VB_W / 9)} y2={VB_H} stroke="rgba(255,255,255,0.04)" strokeWidth="1" />
        ))}
        {Array.from({ length: 6 }).map((_, i) => (
          <line key={`h${i}`} x1={0} y1={(i + 1) * (VB_H / 7)} x2={VB_W} y2={(i + 1) * (VB_H / 7)} stroke="rgba(255,255,255,0.04)" strokeWidth="1" />
        ))}

        {/* hazard zone glow rings — drawn first so markers sit on top */}
        {campusLocations.filter(l => isAlerted(l.label)).map(l => {
          const [x, y] = project(l.lat, l.lng);
          return (
            <circle key={`glow-${l.label}`} cx={x} cy={y} r={42} fill="url(#hazardGlow)">
              <animate attributeName="r" values="32;46;32" dur="1.8s" repeatCount="indefinite" />
            </circle>
          );
        })}

        {/* route path: green = safe, red dashed = safe-path reroute */}
        {routePath && (
          <polyline
            points={routePath}
            fill="none"
            stroke={navResult.isSafePath ? '#ef4444' : '#5cdb95'}
            strokeWidth="5"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeDasharray={navResult.isSafePath ? '4 10' : 'none'}
            opacity="0.95"
          />
        )}

        {/* campus block markers */}
        {campusLocations.map(l => {
          const [x, y] = project(l.lat, l.lng);
          const danger = isAlerted(l.label);
          const isDest = l.label === destinationNode;
          return (
            <g key={l.label} transform={`translate(${x},${y})`}>
              <circle r={isDest ? 9 : 6.5} fill={danger ? '#3a1414' : '#143a2f'} stroke={danger ? '#ef4444' : (isDest ? '#5cdb95' : '#3a7a64')} strokeWidth={isDest ? 2.5 : 1.5} />
              <text y={-12} textAnchor="middle" fontSize="11" fontWeight="700" fill={danger ? '#ff8b8b' : (isDest ? '#5cdb95' : '#a3c9b8')}>
                {danger ? '🚨' : getBlockIcon(l.label)} {l.label}
              </text>
            </g>
          );
        })}

        {/* destination pin (drawn above block dot for emphasis) */}
        {dest && (
          <g transform={`translate(${destX},${destY})`}>
            <path d="M0,-26 C-7,-26 -12,-20.5 -12,-13.5 C-12,-4.5 0,8 0,8 C0,8 12,-4.5 12,-13.5 C12,-20.5 7,-26 0,-26 Z" fill="#e74c3c" stroke="#fff" strokeWidth="1.2" />
            <circle cy={-13.5} r={4.5} fill="#fff" />
          </g>
        )}

        {/* live "you are here" marker */}
        {liveLocation && (
          <g transform={`translate(${liveX},${liveY})`}>
            <circle r={20} fill="url(#liveDotGlow)" />
            <circle r={7} fill="#ff3b30" stroke="#fff" strokeWidth="2.5">
              <animate attributeName="r" values="7;9;7" dur="1.1s" repeatCount="indefinite" />
            </circle>
          </g>
        )}
      </svg>

      <div className="svg-map-legend">
        <div className="svg-map-legend-item"><span className="svg-map-legend-dot" style={{ background: '#ff3b30' }} /> You</div>
        <div className="svg-map-legend-item"><span className="svg-map-legend-dot" style={{ background: '#e74c3c' }} /> Destination</div>
        <div className="svg-map-legend-item"><span className="svg-map-legend-dot" style={{ background: '#5cdb95' }} /> Safe route</div>
        <div className="svg-map-legend-item"><span className="svg-map-legend-dot" style={{ background: '#ef4444' }} /> Hazard zone</div>
      </div>
    </div>
  );
}
