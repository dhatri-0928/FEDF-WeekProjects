import React from 'react';

function circleClass(type) {
  if (type === 'start')       return 'step-circle sc-start';
  if (type === 'destination') return 'step-circle sc-destination';
  if (type === 'turn')        return 'step-circle sc-turn';
  return 'step-circle sc-walk';
}

export default function DirectionsPanel({ selectedCampus, navResult }) {
  if (!selectedCampus) return null;

  /* empty state */
  if (!navResult || navResult.steps.length === 0) {
    return (
      <div className="directions-section">
        <p className="nl-section-label">Turn-by-Turn Directions</p>
        <div className="directions-empty">
          <div className="de-icon">🗺️</div>
          <p>Select a block,<br />then tap <strong>Start Live Navigation</strong></p>
        </div>
      </div>
    );
  }

  return (
    <>
      {/* Route info tiles */}
      <div className="route-info-bar">
        <div className="ri-tile">
          <div className="ri-label">ETA</div>
          <div className="ri-value mint">{navResult.duration}</div>
        </div>
        <div className="ri-tile">
          <div className="ri-label">Distance</div>
          <div className="ri-value amber">{navResult.distance}</div>
        </div>
        <div className="ri-tile">
          <div className="ri-label">Status</div>
          <div className={`ri-value ${navResult.isSafePath ? 'danger' : 'mint'}`}>
            {navResult.isSafePath ? '🚨 Safe Reroute' : navResult.live ? '📡 Live Route' : '≈ Estimated'}
          </div>
        </div>
      </div>

      {navResult.isSafePath && (
        <div className="status-box status-box-danger" style={{ margin: '14px 18px 0' }}>
          🚨 {navResult.dangerBlock} is unsafe right now. This route avoids it and leads you
          to the campus main gate instead.
        </div>
      )}

      {/* Step-by-step list */}
      <div className="directions-section">
        <p className="nl-section-label">Turn-by-Turn Directions</p>

        <ul className="steps-list">
          {navResult.steps.map((step, i) => {
            const isLast = i === navResult.steps.length - 1;
            return (
              <li key={i} className="dir-step">
                {/* left column: circle + connecting line */}
                <div className="step-col-left">
                  <div className={circleClass(step.type)}>{step.icon}</div>
                  {!isLast && <div className="step-line" />}
                </div>

                {/* right column: text */}
                <div className="step-col-right">
                  <div className="step-main">{step.text}</div>
                  <div className="step-sub">{step.sub}</div>
                  {step.dist && (
                    <span className="step-dist-badge">📏 {step.dist}</span>
                  )}
                </div>
              </li>
            );
          })}
        </ul>
      </div>
    </>
  );
}
