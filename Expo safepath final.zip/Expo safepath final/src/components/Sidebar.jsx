import React from 'react';
import { navTabs } from '../data/constants';

export default function Sidebar({ activeTab, setActiveTab, isAdmin, unreadCount, activeAlertCount }) {
  return (
    <aside className="sidebar-menu">
      {navTabs.map(tab => (
        <button
          key={tab.id}
          className={`nav-button ${activeTab === tab.id ? 'active' : ''}`}
          onClick={() => setActiveTab(tab.id)}
        >
          {tab.label}
          {tab.id === 'notifications' && unreadCount > 0 && (
            <span className="sidebar-badge">{unreadCount}</span>
          )}
          {tab.id === 'alerts' && activeAlertCount > 0 && (
            <span className="sidebar-badge sidebar-badge-danger">{activeAlertCount}</span>
          )}
          {tab.id === 'admin' && isAdmin && (
            <span className="sidebar-badge sidebar-badge-admin">ON</span>
          )}
        </button>
      ))}
    </aside>
  );
}
