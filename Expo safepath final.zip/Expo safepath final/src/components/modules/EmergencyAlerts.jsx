import React, { useEffect, useState } from 'react';
import { getAllAlerts, getActiveAlertsForCampus } from '../../utils/alertsStore';

function fmtAgo(iso) {
  const diffMs = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diffMs / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins} min ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs} hr ago`;
  return `${Math.floor(hrs / 24)} day(s) ago`;
}

const TYPE_LABEL = { fire: '🔥 Fire', accident: '🚑 Accident', other: '⚠️ Emergency' };

export default function EmergencyAlerts({ selectedCampus }) {
  const [allAlerts, setAllAlerts] = useState([]);

  useEffect(() => {
    const refresh = () => setAllAlerts(getAllAlerts());
    refresh();
    // Pick up changes made elsewhere (e.g. Admin Dashboard) without a full reload
    const interval = setInterval(refresh, 2000);
    return () => clearInterval(interval);
  }, []);

  const campusActive = selectedCampus
    ? allAlerts.filter(a => a.campusId === selectedCampus.id && !a.clearedAt)
    : [];
  const campusCleared = selectedCampus
    ? allAlerts.filter(a => a.campusId === selectedCampus.id && a.clearedAt).slice(0, 5)
    : [];
  const otherActive = allAlerts.filter(
    a => (!selectedCampus || a.campusId !== selectedCampus.id) && !a.clearedAt
  );

  return (
    <section className="tab-content">
      <div className="interactive-card alert-card-boundary">
        <h2>⚠️ Emergency Alerts</h2>
        <p className="card-desc">
          Live fire / accident alerts raised by campus admins. If your destination block is
          under an active alert, SafePath automatically reroutes you to the nearest safe
          point — away from danger, back toward the campus main gate.
        </p>

        {!selectedCampus && (
          <p className="nl-hint">Select a campus in the Navigation tab to see alerts specific to it.</p>
        )}

        {selectedCampus && campusActive.length === 0 && (
          <div className="status-box status-box-safe" style={{ marginTop: 12 }}>
            ✅ No active alerts at {selectedCampus.label}. All blocks are currently safe.
          </div>
        )}

        {campusActive.length > 0 && (
          <>
            <p className="nl-section-label" style={{ marginTop: 18 }}>
              🚨 ACTIVE AT {selectedCampus.label.toUpperCase()}
            </p>
            <div className="alerts-list">
              {campusActive.map(a => (
                <div key={a.id} className="alert-row alert-row-danger">
                  <span className="alert-type-badge">{TYPE_LABEL[a.type] || TYPE_LABEL.other}</span>
                  <div className="alert-row-body">
                    <div className="alert-row-title">{a.blockLabel}</div>
                    {a.note && <div className="alert-row-note">{a.note}</div>}
                    <div className="alert-row-time">Raised {fmtAgo(a.raisedAt)}</div>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}

        {otherActive.length > 0 && (
          <>
            <p className="nl-section-label" style={{ marginTop: 18 }}>OTHER CAMPUSES — ACTIVE</p>
            <div className="alerts-list">
              {otherActive.map(a => (
                <div key={a.id} className="alert-row alert-row-warn">
                  <span className="alert-type-badge">{TYPE_LABEL[a.type] || TYPE_LABEL.other}</span>
                  <div className="alert-row-body">
                    <div className="alert-row-title">{a.blockLabel}</div>
                    <div className="alert-row-time">{a.campusLabel} · {fmtAgo(a.raisedAt)}</div>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}

        {campusCleared.length > 0 && (
          <>
            <p className="nl-section-label" style={{ marginTop: 18 }}>RECENTLY RESOLVED</p>
            <div className="alerts-list">
              {campusCleared.map(a => (
                <div key={a.id} className="alert-row alert-row-resolved">
                  <span className="alert-type-badge">✅ Resolved</span>
                  <div className="alert-row-body">
                    <div className="alert-row-title">{a.blockLabel}</div>
                    <div className="alert-row-time">Cleared {fmtAgo(a.clearedAt)}</div>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </div>
    </section>
  );
}
