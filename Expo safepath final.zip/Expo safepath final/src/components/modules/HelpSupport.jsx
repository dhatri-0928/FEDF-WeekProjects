import React, { useState } from 'react';

const FAQS = [
  {
    q: 'How does SafePath know if a route is dangerous?',
    a: 'Campus admins raise emergency alerts on specific blocks (fire, accident, etc). Any route passing through an alerted block is automatically marked unsafe and rerouted.',
  },
  {
    q: 'Why isn\u2019t my live location showing on the map?',
    a: 'Make sure location access is allowed for this site in your browser settings, and that GPS/location services are turned on for your device.',
  },
  {
    q: 'Does my session stay logged in if I close the tab?',
    a: 'Yes — sessions are saved in your browser and stay active across tabs and page reloads until you log out.',
  },
  {
    q: 'How do I report a hazard I see on campus?',
    a: 'Hazard reporting for regular users isn\u2019t available yet — alerts are currently raised by campus admins through the Admin Dashboard. Contact your campus admin or security desk directly.',
  },
  {
    q: 'Who can access the Admin Dashboard?',
    a: 'Anyone can open the Admin Dashboard tab, but adding blocks or raising/clearing alerts requires admin login credentials set up for your campus.',
  },
];

export default function HelpSupport() {
  const [openIndex, setOpenIndex] = useState(0);

  return (
    <section className="tab-content">
      <div className="interactive-card">
        <h2>🆘 Help &amp; Support</h2>
        <p className="card-desc">
          Answers to common questions, plus how to reach us if you're still stuck.
        </p>

        <div className="faq-list">
          {FAQS.map((item, i) => {
            const open = openIndex === i;
            return (
              <div key={item.q} className={`faq-item ${open ? 'faq-item-open' : ''}`}>
                <button className="faq-question" onClick={() => setOpenIndex(open ? -1 : i)}>
                  <span>{item.q}</span>
                  <span className="faq-chevron">{open ? '−' : '+'}</span>
                </button>
                {open && <div className="faq-answer">{item.a}</div>}
              </div>
            );
          })}
        </div>

        <div className="admin-section-divider" />
        <h3 className="admin-subheading">📬 Still need help?</h3>
        <div className="support-contact-grid">
          <a href="mailto:support@safepath.app" className="support-contact-card">
            <div className="feature-card-icon">✉️</div>
            <div className="feature-card-title">Email Support</div>
            <div className="feature-card-desc">support@safepath.app</div>
          </a>
          <div className="support-contact-card">
            <div className="feature-card-icon">📞</div>
            <div className="feature-card-title">Campus Security</div>
            <div className="feature-card-desc">Contact your campus security desk for urgent, on-ground emergencies.</div>
          </div>
          <div className="support-contact-card">
            <div className="feature-card-icon">🕒</div>
            <div className="feature-card-title">Response Time</div>
            <div className="feature-card-desc">We typically reply to support emails within 24 hours.</div>
          </div>
        </div>
      </div>
    </section>
  );
}
