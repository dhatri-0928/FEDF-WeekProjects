import React, { useEffect, useState } from 'react';
import {
  getCustomBlocks,
  addCustomBlock,
  updateCustomBlock,
  removeCustomBlock,
} from '../../utils/blocksStore';
import {
  getAllAlerts,
  raiseAlert,
  clearAlert,
} from '../../utils/alertsStore';

export default function AdminDashboard({ selectedCampus, onBlocksChanged }) {
  const [blocks, setBlocks]   = useState([]);
  const [alerts, setAlerts]   = useState([]);

  // form state — add block
  const [label, setLabel] = useState('');
  const [lat, setLat]     = useState('');
  const [lng, setLng]     = useState('');

  // form state — raise alert
  const [alertBlock, setAlertBlock] = useState('');
  const [alertType, setAlertType]   = useState('fire');
  const [alertNote, setAlertNote]   = useState('');

  useEffect(() => {
    if (!selectedCampus) return;
    setBlocks(getCustomBlocks(selectedCampus.id));
    setAlerts(getAllAlerts());
  }, [selectedCampus]);

  if (!selectedCampus) {
    return (
      <section className="tab-content">
        <div className="interactive-card">
          <h2>🛠️ Admin Dashboard</h2>
          <p className="card-desc">
            Select a campus first in the Navigation tab — block management and emergency
            alerts are scoped per campus.
          </p>
        </div>
      </section>
    );
  }

  const refreshBlocks = () => {
    const updated = getCustomBlocks(selectedCampus.id);
    setBlocks(updated);
    onBlocksChanged?.();
  };
  const refreshAlerts = () => setAlerts(getAllAlerts());

  const handleAddBlock = (e) => {
    e.preventDefault();
    if (!label.trim() || !lat || !lng) return;
    addCustomBlock(selectedCampus.id, {
      label: label.trim(),
      lat: parseFloat(lat),
      lng: parseFloat(lng),
    });
    setLabel(''); setLat(''); setLng('');
    refreshBlocks();
  };

  const handleRemoveBlock = (id) => {
    removeCustomBlock(selectedCampus.id, id);
    refreshBlocks();
  };

  const handleUseMyLocation = () => {
    if (!navigator.geolocation) return;
    navigator.geolocation.getCurrentPosition(pos => {
      setLat(pos.coords.latitude.toFixed(6));
      setLng(pos.coords.longitude.toFixed(6));
    });
  };

  const campusAlerts       = alerts.filter(a => a.campusId === selectedCampus.id);
  const activeCampusAlerts = campusAlerts.filter(a => !a.clearedAt);
  const allBlockLabels     = blocks.map(b => b.label);

  const handleRaiseAlert = (e) => {
    e.preventDefault();
    if (!alertBlock) return;
    raiseAlert({
      campusId: selectedCampus.id,
      campusLabel: selectedCampus.label,
      blockLabel: alertBlock,
      type: alertType,
      note: alertNote.trim(),
    });
    setAlertBlock(''); setAlertNote('');
    refreshAlerts();
  };

  const handleClearAlert = (id) => {
    clearAlert(id);
    refreshAlerts();
  };

  return (
    <section className="tab-content">
      <div className="interactive-card">
        <h2>🛠️ Admin Dashboard — {selectedCampus.label}</h2>
        <p className="card-desc">
          Add the named blocks for this campus (OpenStreetMap rarely has things like
          "ECE Block" or "Hostel" tagged), and raise or clear emergency alerts.
          Everything here is saved locally to this browser.
        </p>

        {/* ── Add Block form ───────────────────────────────── */}
        <div className="admin-section-divider" />
        <h3 className="admin-subheading">➕ Add a Campus Block</h3>
        <form onSubmit={handleAddBlock} className="admin-form-grid">
          <input
            className="form-style-input admin-input-dark"
            placeholder="Block name e.g. ECE Block, Boys Hostel…"
            value={label}
            onChange={e => setLabel(e.target.value)}
          />
          <input
            className="form-style-input admin-input-dark"
            placeholder="Latitude"
            value={lat}
            onChange={e => setLat(e.target.value)}
          />
          <input
            className="form-style-input admin-input-dark"
            placeholder="Longitude"
            value={lng}
            onChange={e => setLng(e.target.value)}
          />
          <div style={{ display: 'flex', gap: 8 }}>
            <button type="button" className="btn-action-green" style={{ flex: 1 }} onClick={handleUseMyLocation}>
              📡 Use My Location
            </button>
            <button type="submit" className="btn-action-green-heavy" style={{ flex: 1 }}>
              Add Block
            </button>
          </div>
        </form>

        {/* ── Existing blocks list ─────────────────────────── */}
        <h3 className="admin-subheading" style={{ marginTop: 26 }}>
          📋 Blocks Added for {selectedCampus.label} ({blocks.length})
        </h3>
        {blocks.length === 0 && (
          <p className="nl-hint">No custom blocks added yet — add the first one above.</p>
        )}
        {blocks.length > 0 && (
          <div className="admin-block-list">
            {blocks.map(b => (
              <div key={b.id} className="admin-block-row">
                <div>
                  <div className="admin-block-row-label">{b.label}</div>
                  <div className="admin-block-row-coords">{b.lat.toFixed(5)}, {b.lng.toFixed(5)}</div>
                </div>
                <button className="admin-remove-btn" onClick={() => handleRemoveBlock(b.id)}>✕ Remove</button>
              </div>
            ))}
          </div>
        )}

        {/* ── Raise Alert form ─────────────────────────────── */}
        <div className="admin-section-divider" />
        <h3 className="admin-subheading">🚨 Raise Emergency Alert</h3>
        <p className="card-desc" style={{ marginTop: 0 }}>
          Users navigating to or through the alerted block will be automatically
          redirected to a safe path back toward the campus main gate.
        </p>
        <form onSubmit={handleRaiseAlert} className="admin-form-grid">
          <select
            className="form-style-input admin-input-dark"
            value={alertBlock}
            onChange={e => setAlertBlock(e.target.value)}
          >
            <option value="">Select affected block…</option>
            {allBlockLabels.map(l => <option key={l} value={l}>{l}</option>)}
          </select>
          <select
            className="form-style-input admin-input-dark"
            value={alertType}
            onChange={e => setAlertType(e.target.value)}
          >
            <option value="fire">🔥 Fire</option>
            <option value="accident">🚑 Accident</option>
            <option value="other">⚠️ Other Emergency</option>
          </select>
          <input
            className="form-style-input admin-input-dark"
            placeholder="Optional note…"
            value={alertNote}
            onChange={e => setAlertNote(e.target.value)}
          />
          <button type="submit" className="btn-action-danger" disabled={!alertBlock}>
            🚨 Raise Alert
          </button>
        </form>

        {/* ── Active alerts for this campus ────────────────── */}
        <h3 className="admin-subheading" style={{ marginTop: 26 }}>
          Active Alerts ({activeCampusAlerts.length})
        </h3>
        {activeCampusAlerts.length === 0 && (
          <p className="nl-hint">✅ No active alerts at {selectedCampus.label}.</p>
        )}
        {activeCampusAlerts.length > 0 && (
          <div className="admin-block-list">
            {activeCampusAlerts.map(a => (
              <div key={a.id} className="admin-block-row admin-block-row-danger">
                <div>
                  <div className="admin-block-row-label">{a.blockLabel} — {a.type}</div>
                  <div className="admin-block-row-coords">{a.note || 'No additional notes'}</div>
                </div>
                <button className="admin-clear-btn" onClick={() => handleClearAlert(a.id)}>✅ Mark Safe</button>
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
