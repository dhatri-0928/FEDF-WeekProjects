import React from 'react';

const FEATURES = [
  {
    icon: '📊',
    title: 'Live Safety Dashboard',
    desc: 'Real-time safety score, active alert count, routes mapped, and nearest hazard — all at a glance.',
  },
  {
    icon: '🗺️',
    title: 'Live Navigation & Routing',
    desc: 'Search any campus, see live GPS tracking, and get turn-by-turn directions to any mapped block.',
  },
  {
    icon: '🛰️',
    title: 'SVG Live Map Renderer',
    desc: 'A lightweight interactive map showing your live position, route path, destination, and hazard zones.',
  },
  {
    icon: '🚨',
    title: 'Automatic Safe Rerouting',
    desc: 'If your route passes through an alerted block, SafePath automatically reroutes you away from danger.',
  },
  {
    icon: '⚠️',
    title: 'Emergency Alerts',
    desc: 'See every active and past emergency alert raised for your campus, with type and notes.',
  },
  {
    icon: '🔔',
    title: 'Notifications Feed',
    desc: 'A running log of safety events — alerts raised and resolved — so you never miss an update.',
  },
  {
    icon: '🛠️',
    title: 'Admin Dashboard',
    desc: 'Admins can add custom campus blocks and raise or clear emergency alerts in real time.',
  },
  {
    icon: '🔐',
    title: 'Persistent Sessions',
    desc: 'Sign in once and stay logged in across every tab, with a personalized greeting each time.',
  },
];

export default function Features() {
  return (
    <section className="tab-content">
      <div className="interactive-card">
        <h2>✨ Features</h2>
        <p className="card-desc">
          Everything SafePath gives you to navigate campus safely, in one place.
        </p>

        <div className="features-grid">
          {FEATURES.map(f => (
            <div key={f.title} className="feature-card">
              <div className="feature-card-icon">{f.icon}</div>
              <div className="feature-card-title">{f.title}</div>
              <div className="feature-card-desc">{f.desc}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
