import React, { useState } from 'react';
import { tryAdminLogin } from '../../utils/adminAuth';

export default function AdminLoginGate({ onSuccess }) {
  const [passcode, setPasscode] = useState('');
  const [error, setError]       = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (tryAdminLogin(passcode)) {
      setError('');
      onSuccess();
    } else {
      setError('Incorrect admin passcode. Please try again.');
    }
  };

  return (
    <section className="tab-content">
      <div className="interactive-card" style={{ maxWidth: 420 }}>
        <h2>🔐 Admin Login</h2>
        <p className="card-desc">
          Admin access is separate from regular user sign-in. Enter the admin
          passcode to manage campus blocks and raise / clear emergency alerts.
        </p>
        <form onSubmit={handleSubmit}>
          <label className="form-input-label">ADMIN PASSCODE</label>
          <input
            type="password"
            className="form-style-input admin-input-dark"
            placeholder="Enter admin passcode"
            value={passcode}
            onChange={e => setPasscode(e.target.value)}
          />
          {error && <p className="nl-hint nl-hint-error" style={{ marginTop: 8 }}>{error}</p>}
          <button type="submit" className="btn-action-green-heavy" style={{ marginTop: 16, width: '100%' }}>
            Unlock Admin Dashboard
          </button>
        </form>
      </div>
    </section>
  );
}
