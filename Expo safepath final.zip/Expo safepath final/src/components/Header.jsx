import React from 'react';
import { greetingFor } from '../utils/sessionStore';

export default function Header({ view, openLoginView, openPublicHome, setIsLoginMode, session, onLogout }) {
  if (view === 'home') {
    return (
      <header className="landing-header">
        <div className="brand">
          <strong>SafePath</strong>
          <span className="brand-sub">Navigation &amp; Safety</span>
        </div>
        <div>
          <button className="btn-text-only" onClick={openLoginView}>Login</button>
          <button className="btn-pill-outline" onClick={() => { openLoginView(); setIsLoginMode?.(false); }}>
            Sign Up →
          </button>
        </div>
      </header>
    );
  }

  if (view === 'auth') {
    return (
      <header className="landing-header">
        <div className="brand" style={{ cursor: 'pointer' }} onClick={openPublicHome}>
          <strong>SafePath</strong>
        </div>
        <div>
          <button className="btn-pill-transparent-white" onClick={openPublicHome}>← Home</button>
        </div>
      </header>
    );
  }

  /* main dashboard header */
  return (
    <header className="top-header">
      <div className="nav-logo">SafePath</div>
      {session && (
        <div className="header-greeting">
          <span className="header-greeting-emoji">👋</span>
          <span>{greetingFor(session)}</span>
        </div>
      )}
      <div className="safety-ticker-green">🟢 Navigation Active</div>
      <button className="btn-logout" onClick={onLogout || openPublicHome}>Logout</button>
    </header>
  );
}
