const appStyles = `
:root {
    --bg-emerald-gradient: linear-gradient(135deg, #1b4d3e 0%, #226f54 100%);
    --bg-darker-green: #143a2f;
    --mint-light-card: #f0f7f4;
    --white: #ffffff;
    --text-white: #ffffff;
    --text-muted-mint: #a3c9b8;
    --text-dark-green: #1b4d3e;
    --border-transparent-white: rgba(255, 255, 255, 0.15);
    --danger: #ef4444;
}

body {
    margin: 0;
    font-family: 'Segoe UI', Arial, sans-serif;
    background: #19463a;
    color: var(--text-white);
    line-height: 1.5;
}

.hidden { display: none !important; }

/* ── HOMEPAGE ─────────────────────────────────────── */
#public-homepage { background: var(--bg-emerald-gradient); min-height: 100vh; display: flex; flex-direction: column; }
.landing-header { display: flex; justify-content: space-between; align-items: center; padding: 20px 8%; background: transparent; }
.brand { font-size: 1.4rem; color: var(--text-white); }
.brand-sub { font-size: 0.9rem; color: var(--text-muted-mint); margin-left: 5px; }

.btn-text-only { background: none; border: none; color: var(--text-white); font-weight: 600; cursor: pointer; padding: 10px 20px; }
.btn-pill-outline { background: rgba(255,255,255,0.08); border: 1px solid var(--border-transparent-white); color: var(--text-white); padding: 10px 22px; border-radius: 30px; font-weight: 600; cursor: pointer; }
.btn-pill-outline:hover { background: rgba(255,255,255,0.2); }
.btn-pill-white { background: var(--white); color: var(--text-dark-green); border: none; padding: 14px 32px; border-radius: 30px; font-weight: 600; cursor: pointer; font-size: 1rem; display: inline-block; }
.btn-pill-white:hover { background: #e2e8f0; }
.btn-pill-transparent-white { background: none; border: 1px solid rgba(255,255,255,0.4); color: white; border-radius: 20px; padding: 6px 14px; cursor: pointer; }

.landing-hero-section { padding: 60px 8% 100px; display: flex; flex-direction: column; gap: 60px; }
.hero-typography { max-width: 650px; }
.accent-title { font-size: 4.8rem; line-height: 1.05; font-weight: 800; margin: 0 0 25px; letter-spacing: -2px; }
.italic-title { font-style: italic; font-weight: 300; color: #5cdb95; }
.hero-description { color: var(--text-muted-mint); font-size: 1.15rem; margin-bottom: 35px; line-height: 1.7; }
.hero-action-row { display: flex; gap: 15px; }

.hero-metrics-row { display: flex; gap: 80px; border-top: 1px solid var(--border-transparent-white); padding-top: 40px; margin-top: 20px; }
.metric-num { font-size: 2.2rem; font-weight: bold; color: var(--text-white); }
.metric-label { color: var(--text-muted-mint); font-size: 0.9rem; }

.workflow-section { background: var(--bg-darker-green); padding: 90px 8%; }
.section-tag-label { color: #5cdb95; font-weight: 700; font-size: 0.85rem; letter-spacing: 2px; display: block; margin-bottom: 10px; }
.workflow-title { font-size: 2.6rem; margin: 0 0 10px; font-weight: 700; }
.workflow-title em { color: #5cdb95; font-style: italic; }
.workflow-subtitle { color: var(--text-muted-mint); margin-bottom: 50px; max-width: 600px; font-size: 1.1rem; }
.workflow-cards-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(230px, 1fr)); gap: 20px; }
.step-process-card { background: rgba(255,255,255,0.04); border: 1px solid rgba(255,255,255,0.08); border-radius: 18px; padding: 30px; position: relative; transition: transform 0.3s; }
.step-process-card:hover { transform: translateY(-5px); background: rgba(255,255,255,0.06); }
.step-number { font-size: 2.5rem; font-weight: 800; color: rgba(255,255,255,0.06); position: absolute; top: 20px; right: 25px; }
.step-emoji { font-size: 1.8rem; margin-bottom: 20px; }
.step-process-card h3 { font-size: 1.2rem; margin: 0 0 12px; color: var(--white); }
.step-process-card p { color: var(--text-muted-mint); font-size: 0.95rem; margin: 0; line-height: 1.6; }

/* ── AUTH ─────────────────────────────────────────── */
#auth-page { background: var(--bg-emerald-gradient); min-height: 100vh; display: flex; flex-direction: column; }
.auth-flex-center { flex: 1; display: flex; justify-content: center; align-items: center; padding: 40px 20px; }
.auth-card { background: var(--mint-light-card); color: #1a2e26; padding: 45px 40px; border-radius: 24px; width: 100%; max-width: 440px; box-shadow: 0 20px 40px rgba(0,0,0,0.3); box-sizing: border-box; }
.auth-card h2 { font-size: 1.8rem; margin: 0 0 8px; font-weight: 700; }
#auth-desc { color: #557065; margin: 0 0 30px; font-size: 0.95rem; }
.form-input-label { display: block; font-size: 0.75rem; font-weight: 700; letter-spacing: 1px; color: #445c51; margin-bottom: 8px; margin-top: 18px; }
.form-style-input { width: 100%; padding: 14px 16px; border: 1px solid #cbdcd3; border-radius: 10px; background: var(--white); font-size: 1rem; box-sizing: border-box; color: #12201a; }
.btn-pill-green-submit { width: 100%; background: #226f54; color: white; border: none; padding: 15px; border-radius: 12px; font-size: 1rem; font-weight: 600; cursor: pointer; margin-top: 25px; }
.auth-divider-line { text-align: center; margin: 25px 0; position: relative; }
.auth-divider-line::before { content: ""; position: absolute; width: 100%; height: 1px; background: #cbdcd3; top: 50%; left: 0; z-index: 1; }
.auth-divider-line span { background: var(--mint-light-card); padding: 0 15px; color: #728c80; font-size: 0.9rem; position: relative; z-index: 2; }
.toggle-footer { text-align: center; font-size: 0.95rem; }
#toggle-view-btn { color: #226f54; text-decoration: underline; font-weight: 600; }

/* ── DASHBOARD SHELL ──────────────────────────────── */
.top-header { background: var(--bg-darker-green); display: flex; justify-content: space-between; align-items: center; padding: 0 3%; height: 70px; border-bottom: 1px solid var(--border-transparent-white); }
.nav-logo { font-weight: 800; font-size: 1.5rem; color: var(--white); cursor: pointer; }
.header-greeting { display: flex; align-items: center; gap: 8px; color: var(--text-muted-mint); font-size: 0.92rem; font-weight: 600; }
.header-greeting-emoji { font-size: 1rem; }
.btn-logout { background: none; border: 1px solid var(--danger); color: var(--danger); padding: 6px 14px; border-radius: 8px; font-weight: 600; cursor: pointer; }
.btn-logout:hover { background: var(--danger); color: white; }
.safety-ticker-green { background: rgba(92,219,149,0.15); color: #5cdb95; padding: 6px 16px; border-radius: 20px; font-size: 0.85rem; font-weight: bold; border: 1px solid rgba(92,219,149,0.3); }

.dashboard-container { display: flex; height: calc(100vh - 70px); overflow: hidden; }
.sidebar-menu { width: 220px; background: #164035; border-right: 1px solid var(--border-transparent-white); padding: 20px 12px; display: flex; flex-direction: column; gap: 8px; overflow-y: auto; flex-shrink: 0; }
.sidebar-menu .nav-button { background: none; border: none; color: var(--text-muted-mint); text-align: left; padding: 13px 16px; border-radius: 8px; font-weight: 600; cursor: pointer; font-size: 0.95rem; width: 100%; }
.sidebar-menu .nav-button:hover { background: rgba(255,255,255,0.05); color: white; }
.sidebar-menu .nav-button.active { background: #226f54; color: white; }

#content-area { flex: 1; padding: 0; background: #1b4d3e; overflow: hidden; display: flex; flex-direction: column; }

/* ── NAVIGATION MODULE LAYOUT ─────────────────────── */
.nav-module-wrapper {
  display: flex;
  height: 100%;
  overflow: hidden;
}

/* LEFT PANEL */
.nav-left-panel {
  width: 380px;
  min-width: 380px;
  background: #164035;
  border-right: 1px solid rgba(255,255,255,0.08);
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.nav-left-scroll {
  flex: 1;
  overflow-y: auto;
  scrollbar-width: thin;
  scrollbar-color: #226f54 #143a2f;
}
.nav-left-scroll::-webkit-scrollbar { width: 5px; }
.nav-left-scroll::-webkit-scrollbar-track { background: #143a2f; }
.nav-left-scroll::-webkit-scrollbar-thumb { background: #226f54; border-radius: 4px; }

/* RIGHT PANEL – map */
.nav-right-panel {
  flex: 1;
  position: relative;
  overflow: hidden;
}

/* ── SECTION LABEL ──────────────────────────────── */
.nl-section-label {
  font-size: 0.72rem;
  font-weight: 700;
  color: #5cdb95;
  letter-spacing: 1.6px;
  text-transform: uppercase;
  margin-bottom: 12px;
}

/* ── CAMPUS SELECTOR ──────────────────────────── */
.campus-selector-section {
  padding: 18px 18px 16px;
  border-bottom: 1px solid rgba(255,255,255,0.07);
}
.campus-select-control {
  width: 100%;
  padding: 11px 14px;
  background: #143a2f;
  border: 1px solid rgba(255,255,255,0.18);
  border-radius: 10px;
  color: white;
  font-size: 0.95rem;
  font-family: 'Segoe UI', Arial, sans-serif;
  cursor: pointer;
  outline: none;
  appearance: none;
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='8' viewBox='0 0 12 8'%3E%3Cpath d='M1 1l5 5 5-5' stroke='%235cdb95' stroke-width='1.8' fill='none' stroke-linecap='round'/%3E%3C/svg%3E");
  background-repeat: no-repeat;
  background-position: right 14px center;
  padding-right: 38px;
}
.campus-select-control:focus { border-color: #5cdb95; }

.nl-hint {
  margin-top: 10px;
  font-size: 0.78rem;
  color: #a3c9b8;
  line-height: 1.4;
}
.nl-hint-error { color: #ff8b73; }

.campus-autocomplete-wrap { position: relative; }
.campus-autocomplete-input:disabled { opacity: 0.5; cursor: not-allowed; }
.campus-autocomplete-dropdown {
  position: absolute;
  top: calc(100% + 6px);
  left: 0;
  right: 0;
  z-index: 50;
  max-height: 220px;
  overflow-y: auto;
  background: #143a2f;
  border: 1px solid rgba(255,255,255,0.18);
  border-radius: 10px;
  box-shadow: 0 8px 24px rgba(0,0,0,0.45);
}
.campus-autocomplete-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 10px;
  padding: 10px 14px;
  font-size: 0.88rem;
  color: white;
  cursor: pointer;
}
.campus-autocomplete-item:hover { background: rgba(92,219,149,0.12); }
.campus-autocomplete-dist {
  font-size: 0.72rem;
  color: #5cdb95;
  font-weight: 700;
  white-space: nowrap;
}
.campus-autocomplete-empty {
  padding: 12px 14px;
  font-size: 0.82rem;
  color: #a3c9b8;
}
.campus-autocomplete-name { font-size: 0.88rem; }

.campus-selected-pill {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 10px;
  padding: 11px 14px;
  background: rgba(92,219,149,0.10);
  border: 1px solid #5cdb95;
  border-radius: 10px;
  color: #5cdb95;
  font-weight: 700;
  font-size: 0.92rem;
}
.campus-clear-btn {
  background: transparent;
  border: none;
  color: #a3c9b8;
  font-size: 1rem;
  cursor: pointer;
  line-height: 1;
  padding: 2px 6px;
}
.campus-clear-btn:hover { color: #ff8b73; }

/* ── BLOCKS GRID ─────────────────────────────── */
.blocks-section {
  padding: 16px 18px;
  border-bottom: 1px solid rgba(255,255,255,0.07);
}
.blocks-section-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12px;
}
.blocks-count-pill {
  background: rgba(92,219,149,0.12);
  color: #5cdb95;
  border: 1px solid rgba(92,219,149,0.25);
  padding: 2px 10px;
  border-radius: 12px;
  font-size: 0.75rem;
  font-weight: 700;
}
.blocks-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 7px;
}
.block-card {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 9px 11px;
  background: rgba(255,255,255,0.03);
  border: 1px solid rgba(255,255,255,0.08);
  border-radius: 9px;
  cursor: pointer;
  transition: all 0.18s;
}
.block-card:hover {
  background: rgba(255,255,255,0.07);
  border-color: rgba(92,219,149,0.35);
  transform: translateY(-1px);
}
.block-card.bc-dest {
  background: rgba(92,219,149,0.10);
  border-color: #5cdb95;
  box-shadow: 0 0 0 1px #5cdb95;
}
.block-card.bc-origin {
  background: rgba(46,204,113,0.10);
  border-color: #2ecc71;
}
.block-icon { font-size: 1.15rem; flex-shrink: 0; line-height: 1; }
.block-label {
  font-size: 0.79rem;
  color: #a3c9b8;
  font-weight: 500;
  line-height: 1.3;
}
.block-card.bc-dest .block-label { color: #5cdb95; font-weight: 700; }
.block-card.bc-origin .block-label { color: #2ecc71; font-weight: 700; }

/* ── ROUTE PANEL ─────────────────────────────── */
.route-panel-section {
  padding: 16px 18px;
  border-bottom: 1px solid rgba(255,255,255,0.07);
}
.route-inputs-wrap { position: relative; }
.route-input-row {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-bottom: 8px;
}
.route-dot {
  width: 13px;
  height: 13px;
  border-radius: 50%;
  flex-shrink: 0;
}
.rd-origin { background: #2ecc71; box-shadow: 0 0 6px rgba(46,204,113,0.6); }
.rd-dest   { background: #e74c3c; box-shadow: 0 0 6px rgba(231,76,60,0.6); }

.route-connector {
  position: absolute;
  left: 5px;
  top: 22px;
  bottom: 22px;
  width: 2px;
  background: rgba(255,255,255,0.12);
  border-radius: 2px;
}
.route-node-select {
  flex: 1;
  padding: 10px 13px;
  background: #143a2f;
  border: 1px solid rgba(255,255,255,0.14);
  border-radius: 9px;
  color: white;
  font-size: 0.9rem;
  font-family: 'Segoe UI', Arial, sans-serif;
  outline: none;
  cursor: pointer;
  appearance: none;
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='6' viewBox='0 0 10 6'%3E%3Cpath d='M1 1l4 4 4-4' stroke='%23a3c9b8' stroke-width='1.5' fill='none' stroke-linecap='round'/%3E%3C/svg%3E");
  background-repeat: no-repeat;
  background-position: right 11px center;
  padding-right: 30px;
}
.route-node-select:focus { border-color: #5cdb95; }

.swap-btn {
  display: block;
  margin: 2px auto 8px;
  background: #1b4d3e;
  border: 1px solid rgba(255,255,255,0.18);
  color: #a3c9b8;
  width: 28px;
  height: 28px;
  border-radius: 50%;
  font-size: 0.85rem;
  cursor: pointer;
  line-height: 1;
  transition: all 0.18s;
}
.swap-btn:hover { background: #5cdb95; color: #143a2f; border-color: #5cdb95; }

.get-directions-btn {
  width: 100%;
  background: #5cdb95;
  color: #143a2f;
  border: none;
  padding: 13px;
  border-radius: 10px;
  font-weight: 800;
  font-size: 0.95rem;
  font-family: 'Segoe UI', Arial, sans-serif;
  cursor: pointer;
  margin-top: 10px;
  letter-spacing: 0.2px;
  transition: all 0.2s;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
}
.get-directions-btn:hover { background: #4dcf86; transform: translateY(-1px); box-shadow: 0 4px 14px rgba(92,219,149,0.3); }
.get-directions-btn:disabled { background: rgba(255,255,255,0.08); color: rgba(255,255,255,0.3); cursor: not-allowed; transform: none; box-shadow: none; }

/* ── ROUTE INFO TILES ─────────────────────────── */
.route-info-bar {
  display: flex;
  border-bottom: 1px solid rgba(255,255,255,0.07);
}
.ri-tile {
  flex: 1;
  padding: 12px 14px;
  border-right: 1px solid rgba(255,255,255,0.06);
  text-align: center;
}
.ri-tile:last-child { border-right: none; }
.ri-label { font-size: 0.68rem; text-transform: uppercase; letter-spacing: 0.5px; color: #a3c9b8; margin-bottom: 3px; }
.ri-value { font-size: 1.05rem; font-weight: 800; color: #fff; }
.ri-value.mint  { color: #5cdb95; }
.ri-value.amber { color: #ffcc00; }

/* ── DIRECTIONS PANEL ─────────────────────────── */
.directions-section { padding: 16px 18px 24px; }

.directions-empty {
  text-align: center;
  padding: 28px 10px;
  color: #a3c9b8;
}
.directions-empty .de-icon { font-size: 2.2rem; margin-bottom: 10px; }
.directions-empty p { font-size: 0.88rem; margin: 0; }

.steps-list {
  list-style: none;
  padding: 0;
  margin: 0;
}

.dir-step {
  display: flex;
  align-items: stretch;
}
.step-col-left {
  width: 38px;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
}
.step-circle {
  width: 34px;
  height: 34px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 0.95rem;
  flex-shrink: 0;
  z-index: 1;
}
.sc-start       { background: #2ecc71; }
.sc-walk        { background: #226f54; border: 2px solid rgba(92,219,149,0.3); }
.sc-turn        { background: #1b4d3e; border: 2px solid rgba(255,255,255,0.15); }
.sc-destination { background: #e74c3c; }

.step-line {
  width: 2px;
  flex: 1;
  background: rgba(255,255,255,0.09);
  margin: 3px 0;
  min-height: 16px;
}
.step-col-right {
  flex: 1;
  padding: 2px 0 18px 12px;
}
.dir-step:last-child .step-col-right { padding-bottom: 4px; }
.step-main { font-size: 0.88rem; font-weight: 600; color: #fff; margin-top: 6px; line-height: 1.4; }
.step-sub  { font-size: 0.78rem; color: #a3c9b8; margin-top: 2px; }
.step-dist-badge {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  background: rgba(255,255,255,0.05);
  border: 1px solid rgba(255,255,255,0.1);
  padding: 2px 9px;
  border-radius: 10px;
  font-size: 0.72rem;
  color: #a3c9b8;
  margin-top: 5px;
}

/* ── LIVE-NAV INSTRUCTION OVERLAY ON MAP ────── */
.nav-overlay {
  position: absolute;
  top: 14px;
  left: 14px;
  right: 14px;
  z-index: 1000;
  background: #143a2f;
  border: 1px solid rgba(92,219,149,0.35);
  border-radius: 14px;
  padding: 12px 16px;
  display: flex;
  align-items: center;
  gap: 14px;
  box-shadow: 0 8px 28px rgba(0,0,0,0.5);
  pointer-events: none;
}
.nav-overlay-arrow {
  width: 48px;
  height: 48px;
  background: #226f54;
  border-radius: 10px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.6rem;
  flex-shrink: 0;
}
.nav-overlay-body { flex: 1; }
.nav-overlay-main { font-size: 0.95rem; font-weight: 700; color: #fff; }
.nav-overlay-sub  { font-size: 0.82rem; color: #a3c9b8; margin-top: 2px; }
.nav-overlay-dist { text-align: right; }
.nav-overlay-dist strong { display: block; font-size: 1.15rem; font-weight: 800; color: #5cdb95; }
.nav-overlay-dist span   { font-size: 0.7rem; color: #a3c9b8; }

/* ── LIVE TRACKING BUTTON ───────────────────── */
.live-track-btn {
  position: absolute;
  bottom: 20px;
  right: 16px;
  z-index: 999;
  background: #143a2f;
  border: 2px solid #5cdb95;
  color: #5cdb95;
  padding: 9px 18px;
  border-radius: 30px;
  font-weight: 700;
  font-size: 0.82rem;
  font-family: 'Segoe UI', Arial, sans-serif;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 8px;
  transition: all 0.2s;
  box-shadow: 0 4px 14px rgba(0,0,0,0.4);
}
.live-track-btn:hover { background: #5cdb95; color: #143a2f; }
.live-track-btn.tracking-on { background: #5cdb95; color: #143a2f; }
.live-pulse {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: currentColor;
  animation: lpulse 1.1s ease-in-out infinite;
}
@keyframes lpulse { 0%,100% { transform: scale(1); opacity: 1; } 50% { transform: scale(1.6); opacity: 0.5; } }

/* ── SWITCH (kept for any future use) ──────── */
.switch-ui { position: relative; display: inline-block; width: 50px; height: 26px; }
.switch-ui input { opacity: 0; width: 0; height: 0; }
.slider-round { position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background-color: #445c51; transition: .3s; border-radius: 34px; }
.slider-round:before { position: absolute; content: ""; height: 18px; width: 18px; left: 4px; bottom: 4px; background-color: white; transition: .3s; border-radius: 50%; }
input:checked + .slider-round { background-color: var(--danger); }
input:checked + .slider-round:before { transform: translateX(24px); }

/* ── SIDEBAR BADGES (notifications / active alerts count) ──── */
.nav-button { display: flex; align-items: center; justify-content: space-between; gap: 8px; }
.sidebar-badge {
  background: #5cdb95;
  color: #143a2f;
  font-size: 0.68rem;
  font-weight: 800;
  border-radius: 10px;
  padding: 1px 7px;
  min-width: 18px;
  text-align: center;
  line-height: 1.5;
}
.sidebar-badge-danger { background: var(--danger); color: white; }
.sidebar-badge-admin { background: #ffcc66; color: #3a2c0a; }
.sidebar-divider { height: 1px; background: rgba(255,255,255,0.1); margin: 10px 4px; }
.nav-button-admin { color: #ffcc66; }
.nav-button-admin:hover { background: rgba(255,204,102,0.08); color: #ffd98a; }
.nav-button-admin.active { background: #6b4f1a; color: #ffe6b3; }

/* ── GENERIC TAB CONTENT (alerts / notifications / admin) ──── */
.scrollable-tab-area { flex: 1; overflow-y: auto; padding: 26px 30px; }
.tab-content { max-width: 760px; margin: 0 auto; }
.interactive-card {
  background: rgba(255,255,255,0.04);
  border: 1px solid rgba(255,255,255,0.09);
  border-radius: 18px;
  padding: 28px 30px;
}
.interactive-card h2 { margin: 0 0 8px; font-size: 1.4rem; color: var(--white); }
.interactive-card h3.admin-subheading { margin: 0 0 12px; font-size: 1rem; color: #5cdb95; }
.card-desc { color: var(--text-muted-mint); font-size: 0.92rem; line-height: 1.6; margin: 0 0 16px; }
.alert-card-boundary { border-color: rgba(239,68,68,0.25); }

.status-box {
  background: rgba(92,219,149,0.08);
  border: 1px solid rgba(92,219,149,0.3);
  color: #5cdb95;
  border-radius: 10px;
  padding: 12px 16px;
  font-size: 0.88rem;
  line-height: 1.5;
}
.status-box-safe { background: rgba(92,219,149,0.08); border-color: rgba(92,219,149,0.3); color: #5cdb95; }
.status-box-danger { background: rgba(239,68,68,0.1); border: 1px solid rgba(239,68,68,0.4); color: #ff8b8b; }

/* ── EMERGENCY ALERTS LIST ───────────────────────────────── */
.alerts-list { display: flex; flex-direction: column; gap: 8px; }
.alert-row {
  display: flex;
  gap: 12px;
  align-items: flex-start;
  padding: 12px 14px;
  border-radius: 12px;
  border: 1px solid rgba(255,255,255,0.08);
  background: rgba(255,255,255,0.02);
}
.alert-row-danger { border-color: rgba(239,68,68,0.4); background: rgba(239,68,68,0.07); }
.alert-row-warn   { border-color: rgba(255,204,102,0.3); background: rgba(255,204,102,0.05); }
.alert-row-resolved { opacity: 0.7; }
.alert-type-badge {
  font-size: 0.72rem;
  font-weight: 700;
  white-space: nowrap;
  padding: 3px 9px;
  border-radius: 10px;
  background: rgba(255,255,255,0.06);
  color: #fff;
  flex-shrink: 0;
}
.alert-row-body { flex: 1; }
.alert-row-title { font-size: 0.92rem; font-weight: 700; color: #fff; }
.alert-row-note { font-size: 0.82rem; color: #a3c9b8; margin-top: 3px; }
.alert-row-time { font-size: 0.74rem; color: #8aa89a; margin-top: 4px; }

/* ── NOTIFICATIONS LIST ──────────────────────────────────── */
.notif-list { display: flex; flex-direction: column; gap: 8px; }
.notif-row {
  padding: 12px 14px;
  border-radius: 12px;
  border-left: 3px solid #5cdb95;
  background: rgba(255,255,255,0.03);
}
.notif-row-danger  { border-left-color: var(--danger); }
.notif-row-success { border-left-color: #5cdb95; }
.notif-row-info    { border-left-color: #4a9eff; }
.notif-row.notif-read { opacity: 0.55; }
.notif-row-title { font-size: 0.9rem; font-weight: 700; color: #fff; }
.notif-row-body { font-size: 0.82rem; color: #a3c9b8; margin-top: 3px; line-height: 1.5; }
.notif-row-time { font-size: 0.72rem; color: #8aa89a; margin-top: 6px; }

/* ── ADMIN DASHBOARD ─────────────────────────────────────── */
.admin-section-divider { height: 1px; background: rgba(255,255,255,0.1); margin: 24px 0; }
.admin-form-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 10px;
}
.admin-form-grid > select.admin-input-dark,
.admin-form-grid > input.admin-input-dark { grid-column: span 1; }
.admin-form-grid > div { grid-column: 1 / -1; }
.admin-input-dark {
  background: #143a2f !important;
  color: #fff !important;
  border: 1px solid rgba(255,255,255,0.18) !important;
  margin-top: 0 !important;
}
.admin-input-dark::placeholder { color: #6b9c84; }
.btn-action-green {
  background: rgba(92,219,149,0.12);
  color: #5cdb95;
  border: 1px solid rgba(92,219,149,0.4);
  padding: 12px 18px;
  border-radius: 9px;
  font-weight: 700;
  cursor: pointer;
  font-family: 'Segoe UI', Arial, sans-serif;
}
.btn-action-green:hover { background: rgba(92,219,149,0.2); }
.btn-action-green-heavy {
  background: #5cdb95;
  color: #143a2f;
  border: none;
  padding: 12px 18px;
  border-radius: 9px;
  font-weight: 800;
  cursor: pointer;
  font-family: 'Segoe UI', Arial, sans-serif;
}
.btn-action-green-heavy:hover { background: #4dcf86; }
.btn-action-danger {
  background: var(--danger);
  color: white;
  border: none;
  padding: 12px 18px;
  border-radius: 9px;
  font-weight: 800;
  cursor: pointer;
  font-family: 'Segoe UI', Arial, sans-serif;
  grid-column: 1 / -1;
}
.btn-action-danger:hover { background: #d63a3a; }
.btn-action-danger:disabled { background: rgba(255,255,255,0.08); color: rgba(255,255,255,0.3); cursor: not-allowed; }

.admin-block-list { display: flex; flex-direction: column; gap: 8px; }
.admin-block-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 12px;
  padding: 11px 14px;
  background: rgba(255,255,255,0.03);
  border: 1px solid rgba(255,255,255,0.08);
  border-radius: 10px;
}
.admin-block-row-danger { border-color: rgba(239,68,68,0.4); background: rgba(239,68,68,0.07); }
.admin-block-row-label { font-size: 0.9rem; font-weight: 700; color: #fff; }
.admin-block-row-coords { font-size: 0.76rem; color: #a3c9b8; margin-top: 2px; }
.admin-remove-btn, .admin-clear-btn {
  background: none;
  border: 1px solid rgba(255,255,255,0.2);
  color: #a3c9b8;
  padding: 6px 12px;
  border-radius: 8px;
  font-size: 0.78rem;
  font-weight: 700;
  cursor: pointer;
  white-space: nowrap;
  font-family: 'Segoe UI', Arial, sans-serif;
}
.admin-remove-btn:hover { border-color: var(--danger); color: #ff8b8b; }
.admin-clear-btn { border-color: #5cdb95; color: #5cdb95; }
.admin-clear-btn:hover { background: rgba(92,219,149,0.15); }

/* ── DANGER VARIANTS for existing components ─────────────── */
.block-card.bc-danger {
  background: rgba(239,68,68,0.1);
  border-color: var(--danger);
  box-shadow: 0 0 0 1px var(--danger);
  animation: dangerPulseCard 1.4s ease-in-out infinite;
}
.block-card.bc-danger .block-label { color: #ff8b8b; font-weight: 700; }
@keyframes dangerPulseCard { 0%,100% { box-shadow: 0 0 0 1px var(--danger); } 50% { box-shadow: 0 0 0 4px rgba(239,68,68,0.25); } }

.get-directions-btn-danger { background: var(--danger); color: white; }
.get-directions-btn-danger:hover { background: #d63a3a; box-shadow: 0 4px 14px rgba(239,68,68,0.4); }

.ri-value.danger { color: #ff8b8b; }

.nav-overlay-danger {
  border-color: rgba(239,68,68,0.5);
  background: #3a1414;
}
.nav-overlay-danger .nav-overlay-arrow { background: var(--danger); }
.nav-overlay-danger .nav-overlay-dist strong { color: #ff8b8b; }

/* ── LIVE SAFETY DASHBOARD (KPI cards) ───────────────────── */
.safety-dash { max-width: 980px; }
.safety-dash-header h2 { margin: 0 0 6px; color: var(--white); font-size: 1.5rem; }
.safety-dash-header p { margin: 0 0 26px; color: var(--text-muted-mint); font-size: 0.95rem; }

.kpi-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 16px;
  margin-bottom: 26px;
}
@media (max-width: 900px) { .kpi-grid { grid-template-columns: repeat(2, 1fr); } }

.kpi-card {
  background: rgba(255,255,255,0.04);
  border: 1px solid rgba(255,255,255,0.09);
  border-radius: 16px;
  padding: 20px 18px;
  display: flex;
  flex-direction: column;
  gap: 4px;
  transition: transform 0.18s;
}
.kpi-card:hover { transform: translateY(-2px); }
.kpi-card-danger { background: rgba(239,68,68,0.08); border-color: rgba(239,68,68,0.3); }
.kpi-icon { font-size: 1.6rem; margin-bottom: 4px; }
.kpi-value { font-size: 2.1rem; font-weight: 800; color: var(--white); line-height: 1; }
.kpi-unit { font-size: 1rem; font-weight: 600; color: var(--text-muted-mint); margin-left: 2px; }
.kpi-label { font-size: 0.85rem; font-weight: 700; color: var(--text-muted-mint); margin-top: 6px; }
.kpi-sub { font-size: 0.78rem; color: #6b9c84; }

.safety-dash-cta { margin-top: 10px; }
.dash-banner {
  display: flex;
  align-items: flex-start;
  gap: 12px;
  padding: 16px 18px;
  border-radius: 14px;
  font-size: 0.92rem;
  line-height: 1.5;
}
.dash-banner span { font-size: 1.3rem; flex-shrink: 0; }
.dash-banner-safe { background: rgba(92,219,149,0.1); border: 1px solid rgba(92,219,149,0.3); color: #c9eddb; }
.dash-banner-danger { background: rgba(239,68,68,0.1); border: 1px solid rgba(239,68,68,0.35); color: #ffd0d0; }

/* ── SVG LIVE MAP RENDERER ────────────────────────────────── */
.svg-map-wrap {
  position: relative;
  width: 100%;
  height: 100%;
  min-height: 420px;
  background: radial-gradient(circle at 30% 20%, #1f5443 0%, #102e25 70%, #0c2620 100%);
  overflow: hidden;
}
.svg-map-empty {
  position: absolute;
  inset: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  gap: 10px;
  color: var(--text-muted-mint);
  text-align: center;
  padding: 0 30px;
}
.svg-map-empty-icon { font-size: 2.4rem; }
.svg-map-status {
  position: absolute;
  top: 14px;
  left: 14px;
  right: 14px;
  z-index: 5;
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 16px;
  border-radius: 12px;
  font-size: 0.85rem;
  font-weight: 700;
  backdrop-filter: blur(6px);
}
.svg-map-status-safe   { background: rgba(92,219,149,0.16); border: 1px solid rgba(92,219,149,0.4); color: #5cdb95; }
.svg-map-status-danger { background: rgba(239,68,68,0.18); border: 1px solid rgba(239,68,68,0.45); color: #ff8b8b; animation: dangerPulseCard 1.4s ease-in-out infinite; }
.svg-map-legend {
  position: absolute;
  bottom: 14px;
  left: 14px;
  z-index: 5;
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  background: rgba(10,30,24,0.7);
  border: 1px solid rgba(255,255,255,0.1);
  border-radius: 10px;
  padding: 8px 12px;
  backdrop-filter: blur(6px);
}
.svg-map-legend-item { display: flex; align-items: center; gap: 6px; font-size: 0.72rem; color: var(--text-muted-mint); font-weight: 600; }
.svg-map-legend-dot { width: 9px; height: 9px; border-radius: 50%; flex-shrink: 0; }

.map-mode-toggle {
  position: absolute;
  top: 14px;
  right: 14px;
  z-index: 20;
  display: flex;
  gap: 4px;
  background: rgba(10,30,24,0.75);
  border: 1px solid rgba(255,255,255,0.12);
  border-radius: 10px;
  padding: 4px;
  backdrop-filter: blur(6px);
}
.map-mode-toggle button {
  background: none;
  border: none;
  color: var(--text-muted-mint);
  font-size: 0.78rem;
  font-weight: 700;
  padding: 6px 10px;
  border-radius: 7px;
  cursor: pointer;
}
.map-mode-toggle button.active { background: #226f54; color: white; }

/* ── FEATURES MODULE ──────────────────────────────────────── */
.features-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 14px;
  margin-top: 8px;
}
@media (max-width: 700px) { .features-grid { grid-template-columns: 1fr; } }

.feature-card {
  background: rgba(255,255,255,0.04);
  border: 1px solid rgba(255,255,255,0.09);
  border-radius: 14px;
  padding: 18px;
  transition: transform 0.18s, border-color 0.18s;
}
.feature-card:hover { transform: translateY(-2px); border-color: rgba(92,219,149,0.35); }
.feature-card-icon { font-size: 1.5rem; margin-bottom: 8px; }
.feature-card-title { font-weight: 700; color: var(--white); font-size: 0.98rem; margin-bottom: 6px; }
.feature-card-desc { color: var(--text-muted-mint); font-size: 0.85rem; line-height: 1.5; }

/* ── HELP & SUPPORT MODULE ────────────────────────────────── */
.faq-list { display: flex; flex-direction: column; gap: 10px; margin-top: 6px; }
.faq-item {
  background: rgba(255,255,255,0.03);
  border: 1px solid rgba(255,255,255,0.08);
  border-radius: 12px;
  overflow: hidden;
}
.faq-item-open { border-color: rgba(92,219,149,0.3); background: rgba(92,219,149,0.04); }
.faq-question {
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 12px;
  background: none;
  border: none;
  color: var(--white);
  font-size: 0.92rem;
  font-weight: 600;
  text-align: left;
  padding: 14px 16px;
  cursor: pointer;
}
.faq-chevron { color: #5cdb95; font-size: 1.2rem; font-weight: 800; flex-shrink: 0; }
.faq-answer { padding: 0 16px 16px; color: var(--text-muted-mint); font-size: 0.87rem; line-height: 1.6; }

.support-contact-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 14px;
  margin-top: 8px;
}
@media (max-width: 700px) { .support-contact-grid { grid-template-columns: 1fr; } }
.support-contact-card {
  display: block;
  background: rgba(255,255,255,0.04);
  border: 1px solid rgba(255,255,255,0.09);
  border-radius: 14px;
  padding: 18px;
  text-decoration: none;
  transition: transform 0.18s, border-color 0.18s;
}
.support-contact-card:hover { transform: translateY(-2px); border-color: rgba(92,219,149,0.35); }

`;

export default appStyles;
