/* ─── real walking route via public OSRM (foot profile) ───────
 * Free public router, no API key required.
 * ──────────────────────────────────────────────────────────── */

const OSRM_FOOT_ENDPOINT = 'https://routing.openstreetmap.de/routed-foot/route/v1/foot';

/**
 * Returns { geometry: [[lat,lng], ...], distance (m), duration (s) }
 * or null if the route could not be fetched (caller should fall back
 * to a straight-line estimate).
 */
export async function fetchWalkingRoute(origin, dest) {
  try {
    const url = `${OSRM_FOOT_ENDPOINT}/${origin.lng},${origin.lat};${dest.lng},${dest.lat}?overview=full&geometries=geojson`;
    const res = await fetch(url);
    if (!res.ok) throw new Error(`OSRM error ${res.status}`);
    const data = await res.json();
    const route = data.routes?.[0];
    if (!route) return null;

    return {
      geometry: route.geometry.coordinates.map(([lng, lat]) => [lat, lng]),
      distance: route.distance,
      duration: route.duration,
    };
  } catch (err) {
    console.warn('Live route fetch failed, falling back to straight line:', err);
    return null;
  }
}
