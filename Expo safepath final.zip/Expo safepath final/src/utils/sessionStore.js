/* ─── Session Management ────────────────────────────────────────
 * Stores the logged-in user's session (name + email) so the app
 * remembers who's signed in, can show a personalized greeting, and
 * keeps that state in sync across every open browser tab.
 *
 * Uses localStorage (not sessionStorage) specifically because it is
 * shared across tabs of the same browser — paired with the native
 * `storage` event so other tabs react immediately when one tab logs
 * in or out, plus a light poll as a fallback for same-tab updates
 * (the `storage` event never fires in the tab that made the change).
 * ──────────────────────────────────────────────────────────── */

const SESSION_KEY = 'safepath_session_v1';

function readJSON(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}

function writeJSON(key, value) {
  try {
    if (value == null) localStorage.setItem(key, '');
    else localStorage.setItem(key, JSON.stringify(value));
  } catch { /* ignore (private mode / storage full) */ }
}

/** Returns { name, email, loginAt } or null if nobody is signed in. */
export function getSession() {
  return readJSON(SESSION_KEY, null);
}

export function isLoggedIn() {
  return !!getSession();
}

/** Persist a new session — called right after a successful sign in / sign up. */
export function startSession({ name, email }) {
  const session = {
    name: (name || '').trim() || (email ? email.split('@')[0] : 'Explorer'),
    email: (email || '').trim(),
    loginAt: new Date().toISOString(),
  };
  writeJSON(SESSION_KEY, session);
  return session;
}

/** Clear the session — called on logout, in every tab. */
export function endSession() {
  try { localStorage.removeItem(SESSION_KEY); } catch { /* ignore */ }
}

/**
 * Subscribe to session changes from ANY tab (including this one).
 * Returns an unsubscribe function. Combines the `storage` event
 * (fires in *other* tabs) with a short poll (catches the *current*
 * tab's own writes, since `storage` skips the originating tab).
 */
export function onSessionChange(callback) {
  let last = JSON.stringify(getSession());

  const check = () => {
    const current = JSON.stringify(getSession());
    if (current !== last) {
      last = current;
      callback(getSession());
    }
  };

  const onStorage = (e) => {
    if (!e.key || e.key === SESSION_KEY) check();
  };

  window.addEventListener('storage', onStorage);
  const interval = setInterval(check, 1000);

  return () => {
    window.removeEventListener('storage', onStorage);
    clearInterval(interval);
  };
}

/** Friendly greeting based on the time of day + the user's name. */
export function greetingFor(session) {
  if (!session) return 'Welcome';
  const hour = new Date().getHours();
  const part = hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening';
  return `${part}, ${session.name}`;
}
