/* ─── helpers ──────────────────────────────────────────── */
function haversine(lat1, lng1, lat2, lng2) {
  const R = 6371e3;
  const p1 = (lat1 * Math.PI) / 180;
  const p2 = (lat2 * Math.PI) / 180;
  const dp = ((lat2 - lat1) * Math.PI) / 180;
  const dl = ((lng2 - lng1) * Math.PI) / 180;
  const a =
    Math.sin(dp / 2) ** 2 +
    Math.cos(p1) * Math.cos(p2) * Math.sin(dl / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function getBearing(lat1, lng1, lat2, lng2) {
  const dL = ((lng2 - lng1) * Math.PI) / 180;
  const r1 = (lat1 * Math.PI) / 180;
  const r2 = (lat2 * Math.PI) / 180;
  const y = Math.sin(dL) * Math.cos(r2);
  const x =
    Math.cos(r1) * Math.sin(r2) -
    Math.sin(r1) * Math.cos(r2) * Math.cos(dL);
  return ((Math.atan2(y, x) * 180) / Math.PI + 360) % 360;
}

const CARDINALS = ['North', 'Northeast', 'East', 'Southeast', 'South', 'Southwest', 'West', 'Northwest'];
const ARROWS    = ['↑',     '↗',          '→',    '↘',          '↓',     '↙',          '←',    '↖'];

const cardinal = b => CARDINALS[Math.round(b / 45) % 8];
const arrow    = b => ARROWS[Math.round(b / 45) % 8];

const WP = [
  'the main corridor',
  'the central courtyard',
  'the pedestrian crosswalk',
  'the covered walkway',
  'the T‑junction near the notice board',
  'the steps near the water fountain',
  'the academic block junction',
];

function fmtDist(m) {
  return m < 1000 ? `${Math.round(m)} m` : `${(m / 1000).toFixed(1)} km`;
}
function fmtTime(s) {
  return s < 90 ? '1 min' : `${Math.ceil(s / 60)} min`;
}

/* ─── main export ──────────────────────────────────────── */
export function generateNavSteps(origin, destination) {
  if (!origin || !destination || origin.label === destination.label) {
    return { steps: [], distance: '0 m', duration: '0 min', rawDistance: 0, rawDuration: 0 };
  }

  const rawDistance = haversine(origin.lat, origin.lng, destination.lat, destination.lng);
  const rawDuration = rawDistance / 1.4;           // walking speed 1.4 m/s
  const bear        = getBearing(origin.lat, origin.lng, destination.lat, destination.lng);
  const wp          = [...WP].sort(() => Math.random() - 0.5);

  const steps = [];

  // 1 – Start
  steps.push({ type: 'start', icon: '🔵', text: `Start at ${origin.label}`,        sub: 'Your current location',           dist: '' });

  // 2 – First walk segment
  steps.push({ type: 'walk',  icon: arrow(bear),              text: `Head ${cardinal(bear)} on the campus pathway`, sub: 'Follow the paved walkway',        dist: fmtDist(rawDistance * 0.40) });

  // 3 – Mid waypoint (only if far enough)
  if (rawDistance > 150) {
    steps.push({ type: 'turn', icon: arrow((bear + 22) % 360), text: `Continue through ${wp[0]}`,          sub: 'Keep walking straight ahead',     dist: fmtDist(rawDistance * 0.35) });
  }

  // 4 – Second mid waypoint (only if very far)
  if (rawDistance > 380) {
    steps.push({ type: 'turn', icon: arrow((bear - 18 + 360) % 360), text: `Pass through ${wp[1]}`,       sub: 'Destination will be ahead on your right', dist: fmtDist(rawDistance * 0.20) });
  }

  // 5 – Arrive
  steps.push({ type: 'destination', icon: '📍', text: `Arrive at ${destination.label}`, sub: 'You have reached your destination', dist: '' });

  return {
    steps,
    distance: fmtDist(rawDistance),
    duration: fmtTime(rawDuration),
    rawDistance,
    rawDuration,
  };
}

/**
 * Combines the simulated turn-by-turn text with a real OSRM route
 * (real distance/duration + real road/path geometry for the map),
 * when one is available. Falls back to the haversine estimate +
 * straight line otherwise.
 */
export function buildNavResult(origin, destination, realRoute) {
  const base = generateNavSteps(origin, destination);
  if (!realRoute) {
    return { ...base, geometry: [[origin.lat, origin.lng], [destination.lat, destination.lng]], live: false };
  }
  return {
    ...base,
    distance: fmtDist(realRoute.distance),
    duration: fmtTime(realRoute.duration),
    rawDistance: realRoute.distance,
    rawDuration: realRoute.duration,
    geometry: realRoute.geometry,
    live: true,
  };
}

/**
 * Builds a "safe path" result when the user's chosen destination
 * block currently has an active emergency alert (fire / accident).
 * Instead of routing them into danger, this routes them away from
 * the alerted block, back toward the campus's main gate / entrance
 * node (the safest, most obvious rally point).
 *
 * `mainGate` is a { label, lat, lng } location for the campus —
 * found by matching block labels containing "gate" / "entrance",
 * or falling back to the campus's own center coordinates.
 */
export function buildSafePathResult(origin, dangerBlock, mainGate, realRoute) {
  const safeTarget = { label: mainGate.label, lat: mainGate.lat, lng: mainGate.lng };
  const base = generateNavSteps(origin, safeTarget);

  // Override the step text to make it clear this is a safety reroute
  const steps = base.steps.map((step, i) => {
    if (i === 0) {
      return { ...step, text: `Start at ${origin.label || 'Your Live Location'}`, sub: 'Move away from the danger zone immediately' };
    }
    if (i === base.steps.length - 1) {
      return { ...step, type: 'destination', icon: '🛟', text: `Arrive safely at ${mainGate.label}`, sub: 'You have reached the designated safe assembly point' };
    }
    return { ...step, sub: `${step.sub} — avoiding ${dangerBlock}` };
  });

  steps.unshift({
    type: 'turn',
    icon: '⚠️',
    text: `Danger detected at ${dangerBlock}`,
    sub: 'Rerouting you to the nearest safe exit point',
    dist: '',
  });

  if (!realRoute) {
    return {
      steps,
      distance: base.distance,
      duration: base.duration,
      rawDistance: base.rawDistance,
      rawDuration: base.rawDuration,
      geometry: [[origin.lat, origin.lng], [safeTarget.lat, safeTarget.lng]],
      live: false,
      isSafePath: true,
      dangerBlock,
    };
  }

  return {
    steps,
    distance: fmtDist(realRoute.distance),
    duration: fmtTime(realRoute.duration),
    rawDistance: realRoute.distance,
    rawDuration: realRoute.duration,
    geometry: realRoute.geometry,
    live: true,
    isSafePath: true,
    dangerBlock,
  };
}

/**
 * Find the best "safe rally point" location for a campus: prefers
 * a block literally named like a gate/entrance, otherwise falls
 * back to the campus's own registered center coordinates.
 */
export function findMainGate(campus, blocks) {
  const gate = (blocks || []).find(b => {
    const l = b.label.toLowerCase();
    return l.includes('gate') || l.includes('entrance');
  });
  if (gate) return gate;
  return { label: `${campus.label} Main Entrance`, lat: campus.lat, lng: campus.lng };
}
